#mkdir core
#cd core
#cpio -idm < ../initramfs.cpio

find . | cpio -o --format=newc > ../initramfs.cpio
