#!/bin/sh

docker run -d -p10001:10001 tcache_corruption_challenge
