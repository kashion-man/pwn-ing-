#!/bin/sh

qemu-system-x86_64  \
-m 64M \
-cpu kvm64,+smep,+smap \
-kernel ./bzImage \
-initrd rootfs.img \
-nographic \
-append "console=ttyS0 nokaslr quiet" \
-s
