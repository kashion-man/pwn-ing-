gcc home/pwn/exp.c -o home/pwn/exp -static
find . | cpio -o --format=newc > ../initramfs.cpio
