#!/bin/sh

docker run -d -p10001:10001 house_of_orange_challenge
