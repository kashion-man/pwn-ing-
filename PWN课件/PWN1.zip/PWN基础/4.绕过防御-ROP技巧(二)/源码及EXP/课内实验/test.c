#include <stdio.h>
#include <string.h>
int main(){
    char buf[20] = "/bin/sh";
    printf("%x\n",16);
    printf("%d\n",strlen(buf));
    return 0;
}
