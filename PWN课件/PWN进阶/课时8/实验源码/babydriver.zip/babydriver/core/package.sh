gcc exp.c -o exp
find . | cpio -o --format=newc > ../rootfs.img
