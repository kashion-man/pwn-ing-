#include<stdio.h>
int main(){
    int a = 16;
    char str[] = "Hello World!";
    printf("a = %x\n",a);
    printf("Str = %s\n",str);
    return 0;
}
